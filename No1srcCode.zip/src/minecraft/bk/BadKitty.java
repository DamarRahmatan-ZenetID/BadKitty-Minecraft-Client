package bk;

public class BadKitty {
	public static BadKitty INSTANCE = new BadKitty();
	
	public void startup() {
		normal("Startup");
	}
	
	public void shutdown() {
		normal("Shutdown");
	}
	
	public void normal(String log) {
		System.out.println("[BK] " + log);
	}
}
