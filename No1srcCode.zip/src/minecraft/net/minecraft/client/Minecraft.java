/**
     * Starts the game: initializes the canvas, the title, the settings, etcetera.
     */
    private void startGame() throws LWJGLException, IOException
    {
    	BadKitty.INSTANCE.startup();
		
		//Original Minecraft Codes
    }
	
	/**
     * Shuts down the minecraft applet by stopping the resource downloads, and clearing up GL stuff; called when the
     * application (or web page) is exited.
     */
    public void shutdownMinecraftApplet()
    {
        try
        {
			BadKitty.INSTANCE.shutdown();
			
			//Original Minecraft Codes
    }